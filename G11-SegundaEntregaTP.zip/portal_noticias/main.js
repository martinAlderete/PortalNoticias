let map, marker;
let noticias = [];

// Función para cargar las noticias
function cargarNoticiasIniciales() {
 noticias = noticiasData;
  
  // Mostrar las noticias si tenemos datos desde el archivo externo
  if (noticias.length > 0) {
    mostrarNoticias();
  }
}

function guardarNoticias() {
  console.log('Noticia agregada al listado');
}

function mostrarNoticias() {
  const contenedor = document.getElementById("noticias");
  contenedor.innerHTML = "";
  noticias.forEach((n, i) => {
    const div = document.createElement("div");
    div.className = "noticia";
    div.innerHTML = `
      <strong>${n.titulo}</strong>
      <br>${n.tipo ? `<span class="tipo">${n.tipo}</span> | ` : ""}
      ${n.direccion || "Sin dirección"}
    `;
    div.onclick = () => verDetalle(i);
    contenedor.appendChild(div);
  });
}


document.getElementById("imagen").addEventListener("change", function(e) {
  const preview = document.getElementById("preview");
  const file = e.target.files[0];
  
  if (file) {
    const reader = new FileReader();
    reader.onload = function(e) {
      preview.src = e.target.result;
      preview.style.display = "block";
    }
    reader.readAsDataURL(file);
  } else {
    preview.style.display = "none";
  }
});

document.getElementById("formNoticia").addEventListener("submit", e => {
  e.preventDefault();
  const titulo = document.getElementById("titulo").value;
  const contenido = document.getElementById("contenido").value;
  const tipo = document.getElementById("tipo").value;
  const direccion = document.getElementById("direccion").value;
  const coord = document.getElementById("coordenadas").value;
  const coords = coord ? coord.split(",").map(Number) : null;
  
 
  const preview = document.getElementById("preview");
  const imagen = preview.style.display !== "none" ? preview.src : "";

  const noticia = { 
    titulo, 
    contenido, 
    tipo, 
    direccion, 
    coordenadas: coords,
    imagen
  };
  
  noticias.push(noticia);
  guardarNoticias();
  mostrarNoticias();
  
  document.getElementById("formNoticia").reset();
  document.getElementById("coordenadas").value = "";
  document.getElementById("preview").style.display = "none";
  
  alert("Noticia publicada.");
});

function normalizarDireccion() {
  const direccion = document.getElementById("direccion").value;
  if (!direccion) return alert("Ingresá una dirección.");
  
  const url = `https://servicios.usig.buenosaires.gob.ar/normalizar/?direccion=${encodeURIComponent(direccion)}&geocodificar=true`;
  
  fetch(url)
    .then(res => res.json())
    .then(data => {
      if (data.direccionesNormalizadas && data.direccionesNormalizadas.length > 0) {
        const coords = data.direccionesNormalizadas[0].coordenadas;
        document.getElementById("coordenadas").value = coords.y + "," + coords.x;
        alert("Dirección normalizada");
      } else {
        alert("No se encontró dirección.");
      }
    })
    .catch(() => alert("Error con la API USIG."));
}

function verDetalle(index) {
  const n = noticias[index];
  
  //Escondo las 2 secciones de crear noticia y el listado de noticias
  //Cuando hago click para consultar una noticia y muestro la seccion de detalle
  document.getElementById("seccion-listado").style.display = "none";
  document.getElementById("seccion-crear").style.display = "none";
  document.getElementById("seccion-detalle").style.display = "block";
  
  document.getElementById("detTitulo").textContent = n.titulo;
  document.getElementById("detContenido").textContent = n.contenido;
  document.getElementById("detTipo").textContent = n.tipo || "No especificado";
  document.getElementById("detDireccion").textContent = n.direccion || "Sin dirección";
  
  
  const detImagen = document.getElementById("detImagen");
  if (n.imagen) {
    detImagen.src = n.imagen;
    detImagen.style.display = "block";
  } else {
    detImagen.style.display = "none";
  }

  
  if (n.coordenadas) {
    document.getElementById("map").style.display = "block";
    
    if (!map) {
      map = L.map("map").setView(n.coordenadas, 16);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(map);
    } else {
      map.setView(n.coordenadas, 16);
      if (marker) map.removeLayer(marker);
    }
    
    marker = L.marker(n.coordenadas).addTo(map).bindPopup(n.direccion).openPopup();
  } else {
    document.getElementById("map").style.display = "none";
  }
}

function volver() {
  document.getElementById("seccion-listado").style.display = "block";
  document.getElementById("seccion-crear").style.display = "block";
  document.getElementById("seccion-detalle").style.display = "none";
}

// Ejecutamos la carga de noticias cuando la página esté lista
document.addEventListener('DOMContentLoaded', cargarNoticiasIniciales);