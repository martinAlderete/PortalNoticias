
let noticiasData = [
  {
    "titulo": "Se construyo nuevo modulo en la Universidad Nacional de General Sarmiento",
    "contenido": "Ahora los estudiantes de la carrera de Licenciatura en sistemas tendran acceso a un nuevo modulo con mas de 80 computadoras y 3 proyectores",
    "tipo": "Obras",
    "direccion": "Juan María Gutiérrez 1150, Los Polvorines",
    "coordenadas": [
      -34.52301337831834,
      -58.700488331681164
    ],
    "imagen": ""
  },
  {
    "titulo": "El hospital Austral es condecorado como el mejor hospital de Latinoamerica",
    "contenido": "El Hospital Universitario Austral fue reconocido como el mejor de Latinoamérica, destacándose por su excelencia médica, innovación y atención humanizada.",
    "tipo": "Salud",
    "direccion": "Juan Domingo Perón 1500, Pilar",
    "coordenadas": [
      -34.45716213973599,
      -58.865392443685444
    ],
    "imagen": ""
  },
  {
    "titulo": "Éxito del Torneo de Ajedrez en el Centro Cultural de Los Polvorines",
    "contenido": "Con una nutrida participación de vecinos de todas las edades, se llevó a cabo el primer Torneo Municipal de Ajedrez en las instalaciones del Centro Cultural de Los Polvorines. El evento promovió la integración y el pensamiento estratégico en la comunidad.",
    "tipo": "Cultura",
    "direccion": "Plaza 12 de Octubre, Los Polvorines, Provincia de Buenos Aires", 
    "coordenadas": [
      -34.50764790556743,
      -58.706030528310336 
    ],
    "imagen": "" 
  }
];